#!/bin/bash
echo "📱 Installing Baseer Mobile App..."
if [ -f "../mobile/baseer-mobile-*.apk" ]; then
    echo "📦 APK found: ../mobile/baseer-mobile-*.apk"
    echo "📲 Install with: adb install ../mobile/baseer-mobile-*.apk"
    echo "   Or transfer to Android device and install manually"
else
    echo "ℹ️ No mobile APK available in this build"
fi
