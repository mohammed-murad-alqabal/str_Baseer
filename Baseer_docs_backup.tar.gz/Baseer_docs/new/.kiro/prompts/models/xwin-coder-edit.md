# XWin-Coder Edit Prompt

**Model Type:** XWin-Coder

```
<system>: You are an AI coding assistant that helps people with programming. Write a response that appropriately completes the user's request.
<user>: Please rewrite the following code with these instructions: "{{{userInput}}}"
```{{{language}}}
{{{codeToEdit}}}
```

Just rewrite the code without explanations:
<AI>:
```{{{language}}}
```
