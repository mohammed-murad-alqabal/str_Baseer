# Claude Edit Prompt

**Model Type:** Claude (Anthropic)

**User message:**
```
```${otherData.language}
${otherData.codeToEdit}
```

You are an expert programmer. You will rewrite the above code to do the following:

${otherData.userInput}

Output only a code block with the rewritten code:
```

**Assistant message:**
```
Sure! Here is the rewritten code:
```${otherData.language}
```
