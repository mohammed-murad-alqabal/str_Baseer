#!/bin/bash
set -e
echo "📝 Formatting code..."
dart format .
echo "✅ Code formatted!"
