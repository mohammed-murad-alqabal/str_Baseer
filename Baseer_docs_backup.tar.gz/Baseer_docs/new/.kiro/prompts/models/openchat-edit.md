# OpenChat Edit Prompt

**Model Type:** OpenChat

```
GPT4 Correct User: You are an expert programmer and personal assistant. You are asked to rewrite the following code in order to {{{userInput}}}.
```{{{language}}}
{{{codeToEdit}}}
```
Please only respond with code and put it inside of a markdown code block. Do not give any explanation, but your code should perfectly satisfy the user request.<|end_of_turn|>GPT4 Correct Assistant: Sure thing! Here is the rewritten code that you requested:
```{{{language}}}
```
