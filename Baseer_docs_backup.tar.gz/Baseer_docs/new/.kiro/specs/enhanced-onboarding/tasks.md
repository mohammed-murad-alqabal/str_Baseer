# خطة تنفيذ نظام Onboarding المحسّن

**المشروع:** بصير MVP  
**التاريخ:** 7 ديسمبر 2025  
**المؤلف:** فريق وكلاء تطوير مشروع بصير  
**الحالة:** 🔄 جاهز للتنفيذ

---

## نظرة عامة

هذه خطة تنفيذ تفصيلية لنظام Onboarding المحسّن، مقسمة إلى مهام قابلة للتنفيذ مع تقدير زمني واضح.

### الجدول الزمني

- **المدة الإجمالية**: 5 أسابيع
- **الأسبوع 1-2**: التطوير الأساسي
- **الأسبوع 3**: الاختبارات
- **الأسبوع 4**: التحسين
- **الأسبوع 5**: Beta Testing والنشر

### المقاييس المستهدفة

- Time to First Invoice: < 5 دقائق
- Activation Rate: > 80%
- Test Coverage: > 80%
- NPS: > 50

---

## المهام

### 1. إعداد البنية الأساسية

- [ ] 1.1 إنشاء بنية المجلدات لميزة Onboarding

  - إنشاء `lib/features/onboarding/` مع المجلدات الفرعية (domain, data, presentation)
  - إنشاء `test/features/onboarding/` مع نفس البنية
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 30 دقيقة_

- [ ] 1.2 إضافة التبعيات المطلوبة

  - إضافة video_player, uuid إلى pubspec.yaml
  - تشغيل flutter pub get
  - _Requirements: 1.2_
  - _الوقت المقدر: 15 دقيقة_

- [ ] 1.3 إعداد الأصول (Assets)
  - إنشاء مجلدات assets/videos/ و assets/images/templates/
  - إضافة placeholder للفيديو والصور
  - تحديث pubspec.yaml
  - _Requirements: 1.2, 3.1_
  - _الوقت المقدر: 30 دقيقة_

### 2. تنفيذ Domain Layer

- [ ] 2.1 إنشاء Entities

  - إنشاء `onboarding_state.dart` entity
  - إنشاء `business_type.dart` enum
  - إنشاء `onboarding_step.dart` enum
  - إنشاء `company_info.dart` entity
  - إنشاء `invoice_template.dart` entity
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

- [ ] 2.2 إنشاء Repository Interface

  - إنشاء `onboarding_repository.dart` interface
  - تعريف جميع الدوال المطلوبة (saveState, getState, updateCurrentStep, إلخ)
  - إضافة DartDoc لكل دالة
  - _Requirements: 2.2, 3.3, 4.5, 9.1_
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 2.3 كتابة Unit Tests للـ Entities
  - اختبار OnboardingState.copyWith()
  - اختبار CompanyInfo validation
  - اختبار InvoiceTemplate properties
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

### 3. تنفيذ Data Layer

- [ ] 3.1 إنشاء Isar Models

  - إنشاء `onboarding_state_model.dart` مع Isar annotations
  - إضافة دوال toEntity() و fromEntity()
  - تشغيل build_runner لتوليد الكود
  - _Requirements: 2.2, 9.1_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 3.2 تنفيذ Repository Implementation

  - إنشاء `onboarding_repository_impl.dart`
  - تنفيذ جميع الدوال من Interface
  - إضافة error handling
  - _Requirements: 2.2, 3.3, 4.5, 9.1, 9.2_
  - _الوقت المقدر: 2 ساعة_

- [ ] 3.3 إنشاء Local Datasource

  - إنشاء `onboarding_local_datasource.dart`
  - تنفيذ عمليات Isar (CRUD)
  - إضافة transaction handling
  - _Requirements: 2.2, 9.1_
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 3.4 كتابة Unit Tests للـ Repository

  - اختبار saveState و getState
  - اختبار updateCurrentStep
  - اختبار completeOnboarding
  - اختبار error handling
  - _Requirements: 2.2, 9.1, 9.2_
  - _الوقت المقدر: 2 ساعة_

- [ ]\* 3.5 كتابة Property Test: Round Trip Persistence
  - **Property 12: Progress Persistence**
  - **Validates: Requirements 9.1, 9.2**
  - توليد حالات اختبار متعددة
  - التحقق من أن حفظ واسترجاع الحالة يعيد نفس القيم
  - _الوقت المقدر: 1.5 ساعة_

### 4. تنفيذ Presentation Layer - Providers

- [ ] 4.1 إنشاء Onboarding Provider

  - إنشاء `onboarding_provider.dart` مع Riverpod
  - تنفيذ OnboardingNotifier
  - إضافة دوال nextStep, selectBusinessType, selectTemplate, saveCompanyInfo, complete
  - إضافة error handling
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

- [ ] 4.2 إنشاء Validation Functions

  - إنشاء `validation_helpers.dart`
  - تنفيذ validateCompanyName
  - تنفيذ validatePhoneNumber
  - تنفيذ validateEmail
  - _Requirements: 4.2, 4.3, 4.4_
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 4.3 كتابة Unit Tests للـ Validation

  - اختبار validateCompanyName مع حالات متعددة
  - اختبار validatePhoneNumber مع حالات متعددة
  - اختبار validateEmail مع حالات متعددة
  - _Requirements: 4.2, 4.3, 4.4_
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 4.4 كتابة Property Test: Phone Number Validation

  - **Property 6: Phone Number Validation**
  - **Validates: Requirements 4.3**
  - توليد أرقام صحيحة وخاطئة
  - التحقق من أن التحقق يمر فقط للأرقام الصحيحة
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 4.5 كتابة Property Test: Email Validation
  - **Property 7: Email Validation**
  - **Validates: Requirements 4.4**
  - توليد emails صحيحة وخاطئة
  - التحقق من أن التحقق يمر فقط للـ emails الصحيحة
  - _الوقت المقدر: 1 ساعة_

### 5. تنفيذ Presentation Layer - Widgets المشتركة

- [ ] 5.1 إنشاء OnboardingProgressIndicator Widget

  - عرض مؤشر التقدم بين الخطوات
  - دعم RTL
  - إضافة animations
  - _Requirements: 1.5, 6.3_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 5.2 إنشاء BusinessTypeCard Widget

  - عرض بطاقة نوع العمل مع أيقونة ووصف
  - دعم selection state
  - إضافة animations
  - _Requirements: 2.1_
  - _الوقت المقدر: 1 ساعة_

- [ ] 5.3 إنشاء TemplatePreviewCard Widget

  - عرض معاينة القالب
  - دعم tap للمعاينة الكاملة
  - إضافة animations
  - _Requirements: 3.1, 3.2_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 5.4 إنشاء ContextualTip Widget

  - عرض نصائح contextual
  - دعم "لا تظهر مرة أخرى"
  - إضافة animations
  - _Requirements: 7.1, 7.2, 7.3, 7.4_
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 5.5 كتابة Widget Tests للـ Widgets المشتركة
  - اختبار OnboardingProgressIndicator
  - اختبار BusinessTypeCard
  - اختبار TemplatePreviewCard
  - اختبار ContextualTip
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

### 6. تنفيذ Presentation Layer - Screens

- [ ] 6.1 إنشاء WelcomeScreen

  - عرض شاشة الترحيب مع الشعار
  - إضافة VideoPlayer للفيديو الترحيبي
  - إضافة زر "تخطي"
  - إضافة مؤشر تقدم الفيديو
  - الانتقال التلقائي بعد انتهاء الفيديو
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_
  - _الوقت المقدر: 2 ساعة_

- [ ] 6.2 إنشاء BusinessTypeScreen

  - عرض 4 خيارات لنوع العمل
  - حفظ الاختيار عند الضغط
  - الانتقال التلقائي للخطوة التالية
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 6.3 إنشاء TemplateSelectionScreen

  - عرض 3 قوالب مناسبة لنوع العمل
  - معاينة القالب عند الضغط
  - حفظ القالب المختار
  - الانتقال التلقائي للخطوة التالية
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  - _الوقت المقدر: 2 ساعة_

- [ ] 6.4 إنشاء QuickSetupScreen

  - عرض نموذج بـ 4 حقول
  - إضافة validation لكل حقل
  - عرض رسائل خطأ واضحة
  - حفظ المعلومات عند الضغط على "التالي"
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7_
  - _الوقت المقدر: 2.5 ساعة_

- [ ] 6.5 إنشاء FirstSuccessScreen

  - عرض دليل خطوة بخطوة
  - زر "إضافة عميل" مع بيانات تجريبية
  - رسالة تهنئة بعد حفظ العميل
  - زر "إنشاء فاتورة"
  - رسالة احتفالية بعد إنشاء الفاتورة
  - خيارات: تصدير PDF، إنشاء فاتورة جديدة، بدء الجولة
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7_
  - _الوقت المقدر: 3 ساعة_

- [ ] 6.6 إنشاء GuidedTourScreen

  - عرض جولة تفاعلية للميزات الأساسية
  - مؤشر تقدم للخطوات
  - زر "تخطي" في أي وقت
  - حفظ حالة "مكتمل" عند الانتهاء
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_
  - _الوقت المقدر: 2 ساعة_

- [ ]\* 6.7 كتابة Widget Tests للـ Screens
  - اختبار WelcomeScreen
  - اختبار BusinessTypeScreen
  - اختبار TemplateSelectionScreen
  - اختبار QuickSetupScreen
  - اختبار FirstSuccessScreen
  - اختبار GuidedTourScreen
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 3 ساعة_

### 7. تنفيذ الميزات الإضافية

- [ ] 7.1 إنشاء Help Center Widget

  - عرض الأسئلة الشائعة
  - بحث في المحتوى
  - عرض مقالات المساعدة
  - نموذج "تواصل معنا"
  - مساعدة contextual حسب الشاشة
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_
  - _الوقت المقدر: 2 ساعة_

- [ ] 7.2 تنفيذ حفظ التقدم

  - حفظ الخطوة الحالية عند الإغلاق
  - استئناف من آخر خطوة عند الفتح
  - حذف بيانات التقدم عند الإكمال
  - خيار "إعادة تعيين Onboarding" في الإعدادات
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 7.3 تنفيذ التخصيص حسب نوع العمل

  - نصائح مخصصة لكل نوع عمل
  - قوالب مخصصة لكل نوع عمل
  - أمثلة مخصصة لكل نوع عمل
  - حفظ نوع العمل للتخصيص المستقبلي
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_
  - _الوقت المقدر: 2 ساعة_
    s: Requirements 10.1\*\*
  - التحقق من أن كل نوع عمل له محتوى مخصص
  - التحقق من أن القوالب مناسبة لنوع العمل
  - _الوقت المقدر: 1 ساعة_

### 8. التحسينات والأداء

- [ ] 8.1 تنفيذ Lazy Loading

  - تحميل الفيديو عند الحاجة فقط
  - تحميل الصور بشكل كسول
  - تحميل القوالب عند الطلب
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 8.2 تنفيذ Caching

  - تخزين القوالب في الذاكرة المؤقتة
  - تخزين الصور في الذاكرة المؤقتة
  - تنظيف الذاكرة المؤقتة عند الحاجة
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 8.3 تنفيذ Optimistic UI Updates

  - تحديث الواجهة فوراً قبل حفظ البيانات
  - معالجة الفشل بإعادة الحالة السابقة
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 8.4 تحسين الصور

  - ضغط الصور إلى WebP
  - تحديد دقة مناسبة للشاشة
  - إضافة placeholders
  - _Requirements: 3.1, 3.2_
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 8.5 اختبار الأداء

  - قياس Time to First Screen
  - قياس Step Transition Time
  - قياس Database Save Time
  - قياس Memory Usage
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1.5 ساعة_

- [ ]\* 7.4 كتابة Property Test: Business Type Customization
  - **Property 13: Business Type Customization**
  - \*\*Validate

### 9. الأمان وإمكانية الوصول

- [ ] 9.1 تنفيذ Input Sanitization

  - تنظيف اسم الشركة من أحرف خطرة
  - تنظيف رقم الهاتف
  - تنظيف البريد الإلكتروني
  - _Requirements: 4.2, 4.3, 4.4_
  - _الوقت المقدر: 1 ساعة_

- [ ] 9.2 تنفيذ Secure Storage

  - تشفير البيانات الحساسة (email, phone)
  - استخدام flutter_secure_storage
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 9.3 تحسين إمكانية الوصول

  - إضافة Semantics labels لجميع العناصر
  - التحقق من التباين اللوني (4.5:1)
  - التحقق من حجم الأزرار (48x48)
  - دعم قارئ الشاشة
  - دعم التنقل بلوحة المفاتيح
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

- [ ]\* 9.4 اختبارات إمكانية الوصول
  - اختبار حجم الأزرار
  - اختبار Semantics labels
  - اختبار التباين اللوني
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

### 10. التوطين والترجمة

- [ ] 10.1 إعداد ملفات الترجمة

  - إنشاء ملف strings_ar.dart
  - إنشاء ملف strings_en.dart
  - إضافة جميع النصوص المطلوبة
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 10.2 تنفيذ RTL Support

  - التحقق من دعم RTL في جميع الشاشات
  - اختبار التخطيط في RTL
  - إصلاح أي مشاكل
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 10.3 تنفيذ تنسيق التواريخ والأرقام
  - استخدام intl package
  - تنسيق التواريخ حسب اللغة
  - تنسيق الأرقام حسب اللغة
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 30 دقيقة_

### 11. Integration Tests

- [ ]\* 11.1 كتابة Integration Test: Complete Onboarding Flow

  - اختبار التدفق الكامل من Welcome إلى Completion
  - التحقق من حفظ البيانات في كل خطوة
  - التحقق من الانتقال الصحيح بين الخطوات
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

- [ ]\* 11.2 كتابة Integration Test: Skip Flow

  - اختبار تخطي الفيديو
  - اختبار تخطي الجولة الإرشادية
  - التحقق من الوصول للوجهة الصحيحة
  - _Requirements: 1.4, 6.4_
  - _الوقت المقدر: 1 ساعة_

- [ ]\* 11.3 كتابة Integration Test: Resume Flow
  - اختبار حفظ التقدم
  - اختبار استئناف من آخر خطوة
  - التحقق من استعادة البيانات
  - _Requirements: 9.1, 9.2_
  - _الوقت المقدر: 1 ساعة_

### 12. Checkpoint - التحقق من الجودة

- [ ] 12.1 تشغيل جميع الاختبارات

  - تشغيل flutter test
  - التحقق من نجاح جميع الاختبارات
  - التحقق من Test Coverage > 80%
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 30 دقيقة_

- [ ] 12.2 تشغيل flutter analyze

  - إصلاح جميع الأخطاء
  - إصلاح جميع التحذيرات
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 30 دقيقة_

- [ ] 12.3 مراجعة الكود

  - التحقق من اتباع naming conventions
  - التحقق من اتباع code quality standards
  - التحقق من وجود DartDoc لجميع public APIs
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 12.4 اختبار يدوي
  - اختبار التدفق الكامل على Android
  - اختبار التدفق الكامل على iOS
  - اختبار جميع السيناريوهات (skip, resume, error handling)
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

### 13. التوثيق

- [ ] 13.1 تحديث README

  - إضافة قسم Onboarding
  - شرح كيفية استخدام الميزة
  - إضافة screenshots
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 13.2 إنشاء دليل المطور

  - شرح البنية المعمارية
  - شرح كيفية إضافة خطوات جديدة
  - شرح كيفية تخصيص القوالب
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1.5 ساعة_

- [ ] 13.3 تحديث CHANGELOG
  - إضافة قسم "Enhanced Onboarding"
  - ذكر جميع الميزات الجديدة
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 30 دقيقة_

### 14. Beta Testing

- [ ] 14.1 إعداد Beta Testing

  - اختيار 50 مستخدم beta
  - إنشاء مجموعة Telegram للدعم
  - إعداد نماذج feedback
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

- [ ] 14.2 إطلاق Beta

  - إرسال دعوات للمستخدمين
  - نشر النسخة Beta
  - مراقبة الأداء والأخطاء
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 14.3 جمع Feedback

  - جمع feedback من المستخدمين
  - تحليل البيانات
  - تحديد التحسينات المطلوبة
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 3 ساعات (على مدار أسبوع)_

- [ ] 14.4 تنفيذ التحسينات
  - إصلاح الأخطاء المكتشفة
  - تنفيذ التحسينات المطلوبة
  - إعادة الاختبار
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 4 ساعات_

### 15. النشر للإنتاج

- [ ] 15.1 التحقق النهائي

  - التحقق من جميع معايير القبول
  - التحقق من Time to First Invoice < 5 دقائق
  - التحقق من Activation Rate > 80%
  - التحقق من NPS > 50
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 1 ساعة_

- [ ] 15.2 النشر

  - دمج الكود في main branch
  - إنشاء release tag
  - نشر على App Store و Play Store
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: 2 ساعة_

- [ ] 15.3 المراقبة
  - مراقبة الأداء في الإنتاج
  - مراقبة الأخطاء
  - جمع metrics (Time to First Invoice, Activation Rate)
  - _Requirements: جميع المتطلبات_
  - _الوقت المقدر: مستمر_

---

## ملخص المهام

### إحصائيات

- **إجمالي المهام**: 68 مهمة
- **مهام أساسية**: 45 مهمة
- **مهام اختبار (اختيارية)**: 23 مهمة
- **الوقت المقدر الإجمالي**: ~80 ساعة (أسبوعين عمل مكثف)

### توزيع المهام حسب النوع

| النوع  | العدد | النسبة |
| :----- | :---: | :----: |
| تطوير  |  45   |  66%   |
| اختبار |  23   |  34%   |

### توزيع المهام حسب الأسبوع

| الأسبوع       | المهام | الوصف                                       |
| :------------ | :----: | :------------------------------------------ |
| **الأسبوع 1** |  1-6   | البنية الأساسية + Domain + Data + Providers |
| **الأسبوع 2** |  7-10  | Widgets + Screens + الميزات الإضافية        |
| **الأسبوع 3** | 11-12  | الاختبارات + Checkpoint                     |
| **الأسبوع 4** |   13   | التوثيق + التحسينات                         |
| **الأسبوع 5** | 14-15  | Beta Testing + النشر                        |

### الأولويات

#### عالية جداً (يجب تنفيذها)

- المهام 1-6: البنية الأساسية والطبقات الرئيسية
- المهام 7-10: الشاشات والميزات الأساسية
- المهمة 12: Checkpoint والتحقق من الجودة

#### عالية (موصى بها)

- المهام 11: Integration Tests
- المهمة 13: التوثيق
- المهام 14-15: Beta Testing والنشر

#### متوسطة (اختيارية)

- جميع مهام الاختبار المميزة بـ \*
- المهام 8: التحسينات والأداء (يمكن تأجيلها)

### معايير القبول للإكمال

- ✅ جميع المهام الأساسية (1-10, 12-15) مكتملة
- ✅ Test Coverage > 80%
- ✅ جميع الاختبارات تنجح
- ✅ flutter analyze بدون أخطاء أو تحذيرات
- ✅ Time to First Invoice < 5 دقائق
- ✅ Activation Rate > 80% في Beta
- ✅ NPS > 50 في Beta

### ملاحظات مهمة

1. **المهام المميزة بـ \***: هذه مهام اختبار اختيارية. يمكن تخطيها في المرحلة الأولى والعودة لها لاحقاً.

2. **التقدير الزمني**: الأوقات المقدرة تفترض مطور واحد متفرغ. يمكن تقليل الوقت مع فريق أكبر.

3. **التبعيات**: بعض المهام تعتمد على مهام سابقة. يجب اتباع الترتيب المذكور.

4. **المرونة**: يمكن تعديل الخطة حسب الحاجة، لكن يجب الحفاظ على معايير القبول.

5. **Checkpoint**: المهمة 12 حاسمة. لا تنتقل للمرحلة التالية قبل إكمالها بنجاح.

---

**تم إعداده بواسطة:** فريق وكلاء تطوير مشروع بصير  
**التاريخ:** 7 ديسمبر 2025  
**الإصدار:** 1.0  
**الحالة:** ✅ جاهز للتنفيذ
