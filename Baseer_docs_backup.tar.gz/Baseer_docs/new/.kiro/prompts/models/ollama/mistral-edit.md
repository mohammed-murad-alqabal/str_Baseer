# Mistral Edit Prompt

**Model Type:** Mistral

```
[INST] You are a helpful code assistant. Your task is to rewrite the following code with these instructions: "{{{userInput}}}"
```{{{language}}}
{{{codeToEdit}}}
```

Just rewrite the code without explanations: [/INST]
```{{{language}}}
```
