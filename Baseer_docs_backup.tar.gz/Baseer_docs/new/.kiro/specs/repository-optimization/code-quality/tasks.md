# Implementation Plan - تحسينات جودة الكود

**المشروع:** بصير MVP  
**التاريخ:** 3 ديسمبر 2025  
**المؤلف:** فريق وكلاء تطوير مشروع بصير  
**الحالة:** 🔄 جاهز للتنفيذ

---

## المهام

- [x] 1. إزالة get_it غير المستخدم

  - إزالة `get_it: ^7.6.0` من pubspec.yaml
  - تشغيل `flutter pub get`
  - التحقق من عدم وجود أخطاء
  - _Requirements: 1.1, 1.2, 1.3, 1.4_

- [x] 2. إضافة freezed للمشروع

  - إضافة `freezed_annotation: ^2.4.1` إلى dependencies
  - إضافة `freezed: ^2.4.5` إلى dev_dependencies
  - تشغيل `flutter pub get`
  - _Requirements: 2.1, 2.2_

- [x] 3. تحويل Customer Entity إلى freezed

  - [x] 3.1 نسخ احتياطي من customer.dart الحالي

    - إنشاء نسخة احتياطية
    - _Requirements: 6.1_

  - [x] 3.2 تحويل Customer إلى freezed class

    - إضافة freezed imports
    - إضافة part directive
    - تحويل class إلى factory constructor
    - إزالة copyWith, equals, hashCode اليدوية
    - _Requirements: 3.1, 3.2_

  - [x] 3.3 توليد الكود

    - تشغيل `flutter pub run build_runner build --delete-conflicting-outputs`
    - التحقق من توليد customer.freezed.dart
    - _Requirements: 2.2, 2.3_

  - [x] 3.4 التحقق من الاختبارات

    - تشغيل اختبارات Customer
    - التأكد من نجاح جميع الاختبارات
    - _Requirements: 3.4, 6.2_

  - [x] 3.5 التحقق من Repository
    - التأكد من عمل CustomerRepository بدون تغييرات
    - _Requirements: 3.5, 6.2_

- [x] 4. تحويل Invoice Entity إلى freezed

  - [x] 4.1 نسخ احتياطي من invoice.dart الحالي

    - إنشاء نسخة احتياطية
    - _Requirements: 6.1_

  - [x] 4.2 تحويل Invoice إلى freezed class

    - إضافة freezed imports
    - إضافة part directive
    - تحويل class إلى factory constructor
    - إزالة copyWith, equals, hashCode اليدوية
    - _Requirements: 4.1, 4.2_

  - [x] 4.3 توليد الكود

    - تشغيل `flutter pub run build_runner build --delete-conflicting-outputs`
    - التحقق من توليد invoice.freezed.dart
    - _Requirements: 2.2, 2.3_

  - [x] 4.4 التحقق من الاختبارات

    - تشغيل اختبارات Invoice
    - التأكد من نجاح جميع الاختبارات
    - _Requirements: 4.4, 6.2_

  - [x] 4.5 التحقق من Repository
    - التأكد من عمل InvoiceRepository بدون تغييرات
    - _Requirements: 4.5, 6.2_

- [x] 5. تحويل InvoiceItem Entity إلى freezed

  - [x] 5.1 نسخ احتياطي من invoice_item.dart الحالي

    - إنشاء نسخة احتياطية
    - _Requirements: 6.1_

  - [x] 5.2 تحويل InvoiceItem إلى freezed class

    - إضافة freezed imports
    - إضافة part directive
    - تحويل class إلى factory constructor
    - إزالة copyWith, equals, hashCode اليدوية
    - _Requirements: 5.1, 5.2_

  - [x] 5.3 توليد الكود

    - تشغيل `flutter pub run build_runner build --delete-conflicting-outputs`
    - التحقق من توليد invoice_item.freezed.dart
    - _Requirements: 2.2, 2.3_

  - [x] 5.4 التحقق من الاختبارات
    - تشغيل اختبارات InvoiceItem
    - التأكد من نجاح جميع الاختبارات
    - _Requirements: 5.3, 6.2_

- [x] 6. التحقق النهائي الشامل

  - [x] 6.1 تشغيل flutter analyze

    - يجب أن يكون 0 أخطاء، 0 تحذيرات
    - _Requirements: 6.1_

  - [x] 6.2 تشغيل جميع الاختبارات

    - يجب أن تنجح جميع الـ 518 اختبار
    - _Requirements: 6.2_

  - [x] 6.3 بناء التطبيق

    - بناء للـ Android
    - بناء للـ iOS (إن أمكن)
    - بناء للـ Web
    - _Requirements: 6.3_

  - [x] 6.4 اختبار يدوي
    - تشغيل التطبيق
    - اختبار إضافة عميل
    - اختبار إضافة فاتورة
    - التأكد من عمل كل شيء بشكل طبيعي
    - _Requirements: 6.4_

- [x] 7. تحديث التوثيق

  - [x] 7.1 تحديث CHANGELOG.md

    - إضافة قسم للتحسينات
    - ذكر إزالة get_it
    - ذكر إضافة freezed
    - ذكر تحويل Entities
    - _Requirements: 7.1_

  - [x] 7.2 تحديث README.md (إن لزم)

    - إضافة معلومات عن freezed إن لزم
    - _Requirements: 7.2_

  - [x] 7.3 توثيق استخدام freezed
    - إنشاء دليل بسيط لاستخدام freezed في المشروع
    - إضافة أمثلة
    - _Requirements: 7.3_

---

## ملاحظات التنفيذ

### الأولوية

**عاجلة:** المهام 1-2 (إزالة get_it وإضافة freezed)  
**عالية:** المهام 3-5 (تحويل Entities)  
**متوسطة:** المهام 6-7 (التحقق والتوثيق)

### الوقت المقدر

- المهمة 1: 10 دقائق
- المهمة 2: 10 دقائق
- المهمة 3: 30-45 دقيقة
- المهمة 4: 30-45 دقيقة
- المهمة 5: 20-30 دقيقة
- المهمة 6: 20-30 دقيقة
- المهمة 7: 15-20 دقيقة

**الإجمالي:** 2-3 ساعات

### المخاطر

**منخفضة:**

- إزالة get_it آمنة (غير مستخدم)
- freezed مستقر ومختبر جيداً
- النماذج الحالية بسيطة

**التخفيف:**

- نسخ احتياطي قبل كل تغيير
- اختبار بعد كل خطوة
- التراجع السريع إن لزم

### الفوائد المتوقعة

**تقليل الكود:**

- Customer: من ~60 سطر إلى ~15 سطر (75% تقليل)
- Invoice: من ~100 سطر إلى ~30 سطر (70% تقليل)
- InvoiceItem: من ~40 سطر إلى ~15 سطر (62.5% تقليل)
- **الإجمالي:** تقليل ~140 سطر من الكود المتكرر

**تحسين الجودة:**

- إزالة احتمالية الأخطاء البشرية
- copyWith, equals, hashCode مولدة تلقائياً
- toString مولد تلقائياً
- ضمان immutability

**تحسين تجربة المطور:**

- كود أقل للكتابة
- كود أقل للصيانة
- refactoring أسهل
- أخطاء أقل

---

**تم إعداده بواسطة:** فريق وكلاء تطوير مشروع بصير  
**التاريخ:** 3 ديسمبر 2025  
**الحالة:** 🔄 جاهز للتنفيذ
