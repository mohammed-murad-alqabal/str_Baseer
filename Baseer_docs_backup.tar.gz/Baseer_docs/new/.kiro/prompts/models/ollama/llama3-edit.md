# Llama 3 Edit Prompt

**Model Type:** Llama 3

```
<|begin_of_text|><|start_header_id|>user<|end_header_id|>
```{{{language}}}
{{{codeToEdit}}}
```

Rewrite the above code to satisfy this request: "{{{userInput}}}"<|eot_id|><|start_header_id|>assistant<|end_header_id|>
Sure! Here's the code you requested:
```{{{language}}}
```
