#!/bin/bash
echo "🐹 Deploying Baseer Backend..."
tar -xzf ../backend/baseer-backend*.tar.gz -C ./
chmod +x baseer-api* 2>/dev/null
echo "✅ Backend deployed"
echo "🚀 Start backend: ./baseer-api (or ./baseer-api-minimal)"
