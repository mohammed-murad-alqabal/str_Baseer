# 🌟 بصير - النظام المالي الذكي v1.0

<div align="center">

![بصير Logo](https://img.shields.io/badge/بصير-النظام_المالي_الذكي-006C35?style=for-the-badge&logo=flutter)

[![Flutter](https://img.shields.io/badge/Flutter-3.16.0+-02569B?style=flat&logo=flutter)](https://flutter.dev)
[![Go](https://img.shields.io/badge/Go-1.21+-00ADD8?style=flat&logo=go)](https://golang.org)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15+-336791?style=flat&logo=postgresql)](https://postgresql.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg?style=flat)](LICENSE)

**نظام مالي ذكي شامل لإدارة الفواتير والعملاء مصمم خصيصاً للسوق السعودي**

[🚀 البدء السريع](#-البدء-السريع) • [📱 الميزات](#-الميزات) • [🏗️ الهيكل](#️-الهيكل-التقني) • [📋 التوثيق](#-التوثيق)

</div>

---

## 📋 نظرة عامة

بصير هو نظام مالي ذكي متكامل يهدف إلى تبسيط إدارة الفواتير والعملاء للشركات الصغيرة والمتوسطة في المملكة العربية السعودية. يجمع المشروع بين التقنيات الحديثة والتصميم المحلي المتميز لتقديم تجربة مستخدم استثنائية.

### 🎯 الأهداف الرئيسية
- 📊 **إدارة شاملة للفواتير**: إنشاء وتتبع وإدارة الفواتير بسهولة
- 👥 **إدارة العملاء**: قاعدة بيانات متكاملة للعملاء والتعاملات
- 📈 **تحليلات مالية**: تقارير وإحصائيات تفصيلية
- 🎨 **تجربة محلية**: تصميم مستوحى من الهوية السعودية
- 🔒 **أمان عالي**: حماية متقدمة للبيانات المالية

## 📱 الميزات

### ✅ الميزات المكتملة
- 🎨 **واجهة أنيقة**: تصميم متميز بالألوان السعودية
- 📊 **لوحة تحكم تفاعلية**: إحصائيات ومؤشرات مرئية
- 🧾 **إدارة الفواتير**: إنشاء وتعديل وتتبع الفواتير
- 👥 **إدارة العملاء**: قاعدة بيانات شاملة للعملاء
- 🔍 **بحث وفلترة**: أدوات بحث متقدمة
- 📱 **تصميم متجاوب**: يعمل على جميع أحجام الشاشات
- 🌐 **دعم RTL**: دعم كامل للغة العربية

### 🔄 قيد التطوير
- 🔐 **نظام المصادقة**: تسجيل دخول آمن
- 📈 **تقارير متقدمة**: تحليلات مالية عميقة
- 💳 **نظام الدفع**: ربط بوابات الدفع السعودية
- 📧 **إشعارات**: تنبيهات ذكية للمدفوعات

## 🏗️ الهيكل التقني

### 📱 Frontend (تطبيق الموبايل)
```
التقنية: Flutter 3.16.0+
اللغة: Dart 3.0+
إدارة الحالة: Riverpod 2.4.9
التصميم: Material Design 3
المنصات: Android, iOS, Web, Linux
```

### 🖥️ Backend (الخادم الخلفي)
```
التقنية: Go (Golang)
إطار العمل: Gin Framework
قاعدة البيانات: PostgreSQL
المصادقة: JWT Tokens
API: RESTful
```

### 🗄️ قاعدة البيانات
```
النوع: PostgreSQL 15+
الهيكل: علائقية مع دعم JSON
الأمان: تشفير البيانات الحساسة
النسخ الاحتياطي: آلي ومجدول
```

## 🚀 البدء السريع

### 📋 المتطلبات الأساسية
- Flutter 3.16.0+
- Go 1.21+
- PostgreSQL 15+
- Docker (اختياري)

### ⚡ التثبيت السريع

1. **استنساخ المشروع**
```bash
git clone https://github.com/your-username/baseer-financial-system.git
cd baseer-financial-system
```

2. **إعداد قاعدة البيانات**
```bash
# إنشاء قاعدة البيانات
createdb baseer_db

# تشغيل سكريبتات التهيئة
psql -d baseer_db -f database/init.sql
```

3. **تشغيل الخادم الخلفي**
```bash
cd backend
go mod tidy
go run cmd/main.go
```

4. **تشغيل تطبيق الموبايل**
```bash
cd frontend
flutter pub get
flutter run
```

### 🐳 التشغيل باستخدام Docker
```bash
# تشغيل جميع الخدمات
docker-compose -f docker-compose.dev.yml up

# أو استخدام السكريبت المُعد
./scripts/setup-dev.sh
```

## 📁 هيكل المشروع

```
بصير_النظام_المالي_الذكي_v1.0/
├── 🖥️ backend/                    # الخادم الخلفي (Go)
│   ├── cmd/                       # نقطة البداية
│   ├── internal/                  # الكود الداخلي
│   │   ├── handlers/              # معالجات HTTP
│   │   ├── services/              # طبقة الخدمات
│   │   ├── repository/            # طبقة البيانات
│   │   └── models/                # نماذج البيانات
│   └── Dockerfile.dev             # Docker للتطوير
├── 📱 frontend/                   # تطبيق الموبايل (Flutter)
│   ├── lib/                       # الكود المصدري
│   │   ├── core/                  # الوظائف الأساسية
│   │   ├── features/              # الميزات الرئيسية
│   │   └── shared/                # المكونات المشتركة
│   ├── android/                   # إعدادات Android
│   ├── ios/                       # إعدادات iOS
│   └── assets/                    # الأصول والموارد
├── 🗄️ database/                   # قاعدة البيانات
│   └── init/                      # سكريبتات التهيئة
├── 🔧 scripts/                    # سكريبتات الإعداد
└── 📋 docs/                       # التوثيق والتقارير
```

## 🎨 لقطات الشاشة

### 📱 الشاشة الرئيسية
- تصميم ترحيبي أنيق بالألوان السعودية
- شعار التطبيق مع تأثيرات بصرية
- رسالة ترحيب باللغة العربية

### 📊 لوحة التحكم
- بطاقات إحصائيات تفاعلية
- مؤشرات مرئية للبيانات المهمة
- رسوم بيانية وتشارت

### 🧾 إدارة الفواتير
- قائمة فواتير منظمة
- ألوان مميزة لحالات الفواتير
- بحث وفلترة متقدمة

## 🧪 الاختبار

### تشغيل الاختبارات
```bash
# اختبارات Flutter
cd frontend
flutter test

# اختبارات Go
cd backend
go test ./...
```

### تغطية الاختبارات
```bash
# تقرير تغطية Flutter
flutter test --coverage
genhtml coverage/lcov.info -o coverage/html

# تقرير تغطية Go
go test -coverprofile=coverage.out ./...
go tool cover -html=coverage.out
```

## 📋 التوثيق

### 📚 الوثائق المتاحة
- [📋 تقرير التقييم الشامل](تقرير_التقييم_الشامل.md)
- [🌳 شجرة هيكل المشروع](شجرة_هيكل_المشروع_المُحسن.md)
- [📱 دليل تجربة التطبيق](تقرير_تجربة_التطبيق.md)

### 🔗 روابط مفيدة
- [Flutter Documentation](https://docs.flutter.dev/)
- [Go Documentation](https://golang.org/doc/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)

## 🤝 المساهمة

نرحب بمساهماتكم! يرجى قراءة [دليل المساهمة](CONTRIBUTING.md) قبل البدء.

### 📝 خطوات المساهمة
1. Fork المشروع
2. إنشاء فرع للميزة (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push للفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## 📊 إحصائيات المشروع

- **📁 المجلدات**: 135 مجلد
- **📄 الملفات**: 206 ملف
- **💻 أسطر الكود**: 15,000+ سطر
- **🧪 تغطية الاختبارات**: 75%+
- **📱 المنصات المدعومة**: 4 منصات

## 🏆 التقييم

### 🎯 النتيجة الإجمالية: 85/100 ⭐⭐⭐⭐⭐

- **التصميم والواجهة**: 20/20
- **الوظائف الأساسية**: 18/20
- **الأداء التقني**: 17/20
- **الأمان**: 15/20
- **قابلية الصيانة**: 15/20

## 📞 التواصل والدعم

- **البريد الإلكتروني**: support@baseer-app.com
- **الموقع الإلكتروني**: https://baseer-app.com
- **التوثيق**: https://docs.baseer-app.com

## 📄 الترخيص

هذا المشروع مرخص تحت رخصة MIT - راجع ملف [LICENSE](LICENSE) للتفاصيل.

## 🙏 شكر وتقدير

- فريق Flutter لإطار العمل الرائع
- مجتمع Go للأدوات المتميزة
- مجتمع PostgreSQL لقاعدة البيانات القوية
- جميع المساهمين في المشروع

---

<div align="center">

**صُنع بـ ❤️ في المملكة العربية السعودية**

[![GitHub stars](https://img.shields.io/github/stars/your-username/baseer-financial-system?style=social)](https://github.com/your-username/baseer-financial-system/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/your-username/baseer-financial-system?style=social)](https://github.com/your-username/baseer-financial-system/network/members)

</div>