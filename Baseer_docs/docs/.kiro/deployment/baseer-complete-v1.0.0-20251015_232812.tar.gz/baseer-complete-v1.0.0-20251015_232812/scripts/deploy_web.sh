#!/bin/bash
echo "🌐 Deploying Baseer Web Application..."
tar -xzf ../web/baseer-web-*.tar.gz -C ./web_deploy/
echo "✅ Web application deployed to ./web_deploy/"
echo "🚀 Start a web server: python3 -m http.server 8080 --directory ./web_deploy/"
