# مرجع سريع للـ Hooks

**المشروع:** بصير MVP  
**آخر تحديث:** 4 ديسمبر 2025

---

## 🚀 البدء السريع

### تفعيل جميع الـ Hooks

جميع الـ hooks مفعّلة افتراضياً (`"enabled": true`)

### تعطيل Hook معين

افتح ملف الـ hook وغيّر:

```json
"enabled": false
```

---

## 📋 قائمة سريعة بالـ Hooks

### ⚡ تلقائية (تعمل فوراً)

| Hook             | متى يعمل     | ماذا يفعل         |
| :--------------- | :----------- | :---------------- |
| **auto-analyze** | عند حفظ Dart | `flutter analyze` |
| **auto-format**  | عند حفظ Dart | `dart format`     |

### 🤖 ذكية (تسأل الوكيل)

#### جودة الكود

| Hook                           | متى يعمل            |
| :----------------------------- | :------------------ |
| **check-naming**               | عند حفظ Dart        |
| **check-error-handling**       | عند حفظ Dart        |
| **check-performance-patterns** | عند حفظ Dart        |
| **pre-commit-quality**         | عند ذكر commit/push |
| **check-code-generation**      | عند حفظ Dart        |
| **spec-compliance-check**      | عند حفظ features/   |

#### الأمان

| Hook                            | متى يعمل             |
| :------------------------------ | :------------------- |
| **security-check**              | عند حفظ Dart         |
| **check-dependencies-security** | عند حفظ pubspec.yaml |

#### التوثيق

| Hook                  | متى يعمل             |
| :-------------------- | :------------------- |
| **check-dartdoc**     | عند حفظ Dart         |
| **remind-changelog**  | عند إضافة ميزات      |
| **check-readme-sync** | عند حفظ ملفات رئيسية |
| **check-todo-age**    | بداية الجلسة         |

#### الاختبارات

| Hook                  | متى يعمل     |
| :-------------------- | :----------- |
| **check-tests-exist** | عند حفظ lib/ |
| **run-related-tests** | عند حفظ Dart |

#### التطوير

| Hook                          | متى يعمل              |
| :---------------------------- | :-------------------- |
| **check-version-update**      | عند حفظ lib/          |
| **check-arabic-translation**  | عند حفظ presentation/ |
| **check-state-management**    | عند حفظ providers/    |
| **check-database-operations** | عند حفظ repositories/ |

#### إدارة المشروع

| Hook                    | متى يعمل     |
| :---------------------- | :----------- |
| **project-status**      | بداية الجلسة |
| **weekly-health-check** | بداية الجلسة |

#### الأداء

| Hook                          | متى يعمل        |
| :---------------------------- | :-------------- |
| **check-assets-optimization** | عند حفظ assets/ |

---

## 🎯 حالات الاستخدام الشائعة

### قبل Commit

```
Hook: pre-commit-quality
يشغل: flutter analyze + test + format
```

### عند إضافة ميزة

```
Hooks تعمل تلقائياً:
1. check-tests-exist - يتحقق من الاختبارات
2. check-dartdoc - يتحقق من التوثيق
3. remind-changelog - يذكّر بـ CHANGELOG
4. check-version-update - يذكّر بالإصدار
```

### عند تعديل Model

```
Hook: check-code-generation
يذكّر بـ: flutter pub run build_runner build
```

### عند تعديل Provider

```
Hook: check-state-management
يتحقق من: استخدام Riverpod الصحيح
```

### عند تعديل Repository

```
Hook: check-database-operations
يتحقق من: عمليات Isar الآمنة
```

---

## 🔧 تخصيص سريع

### تغيير filePattern

```json
"filePattern": "lib/features/**/*.dart"
```

### تغيير الـ trigger

```json
"trigger": {
  "type": "onFileSave",  // أو onSessionStart أو onMessage
  "filePattern": "**/*.dart"
}
```

### تعديل الـ prompt

```json
"prompt": "نصك المخصص هنا..."
```

---

## 📊 الإحصائيات

- **المجموع:** 18 hook
- **تلقائية:** 2 (11%)
- **ذكية:** 16 (89%)

---

## 🆘 حل المشاكل

### Hook لا يعمل؟

1. ✅ تحقق من `"enabled": true`
2. ✅ تحقق من `filePattern`
3. ✅ تحقق من الـ `trigger`
4. ✅ راجع `.kiro/logs/`

### كثرة التنبيهات؟

1. عطّل الـ hooks غير الضرورية
2. حسّن الـ `filePattern`
3. استخدم `onSessionStart` بدلاً من `onSave`

---

## 📚 المزيد من المعلومات

- **التوثيق الكامل:** `README.md`
- **التقرير التفصيلي:** `HOOKS_IMPLEMENTATION_REPORT.md`
- **الإطار النظري:** `../.kiro/steering/agents-framework.md`

---

**نصيحة:** ابدأ بتفعيل الـ hooks الأساسية فقط، ثم أضف المزيد تدريجياً!
