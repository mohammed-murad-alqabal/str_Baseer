#!/bin/bash
# Run all tests

set -e

echo "🧪 Running tests..."

flutter test

echo "✅ All tests passed!"
