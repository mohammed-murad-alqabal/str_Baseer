# Alpaca Edit Prompt

**Model Type:** Alpaca

```
Below is an instruction that describes a task, paired with an input that provides further context. Write a response that appropriately completes the request.

### Instruction: Rewrite the code to satisfy this request: "{{{userInput}}}"

### Input:

```{{{language}}}
{{{codeToEdit}}}
```

### Response:

Sure! Here's the code you requested:
```{{{language}}}
```
