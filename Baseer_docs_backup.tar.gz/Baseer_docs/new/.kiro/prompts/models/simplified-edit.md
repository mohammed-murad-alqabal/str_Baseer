# Simplified Edit Prompt

**Model Type:** Generic/Simplified

```
Consider the following code:
```{{{language}}}
{{{codeToEdit}}}
```
Edit the code to perfectly satisfy the following user request:
{{{userInput}}}
Output nothing except for the code. No code block, no English explanation, no start/end tags.
```
