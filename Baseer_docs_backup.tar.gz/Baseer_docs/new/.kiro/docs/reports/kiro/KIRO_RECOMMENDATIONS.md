# توصيات تحسين مجلد .kiro/

**المشروع:** بصير MVP  
**التاريخ:** 8 ديسمبر 2025  
**المؤلف:** فريق وكلاء تطوير مشروع بصير  
**الحالة:** ✅ جاهز للتنفيذ

---

## 🎯 نظرة عامة

هذا الملف يحتوي على توصيات قابلة للتنفيذ لتحسين مجلد `.kiro/` من **92/100** إلى **100/100**.

---

## 📋 قائمة التوصيات

### 🔴 أولوية عالية (Critical)

#### 1. إضافة تكوين MCP

**الملف:** `.kiro/settings/mcp.json`

**الحالة الحالية:** فارغ  
**الأثر:** عالي جداً  
**الوقت المقدر:** 30 دقيقة

**التكوين المقترح:**

```json
{
  "mcpServers": {
    "flutter-docs": {
      "command": "uvx",
      "args": ["flutter-docs-mcp-server@latest"],
      "env": {
        "FASTMCP_LOG_LEVEL": "ERROR"
      },
      "disabled": false,
      "autoApprove": [],
      "priority": 88
    },
    "dart-analyzer": {
      "command": "uvx",
      "args": ["dart-analyzer-mcp-server@latest"],
      "env": {
        "FASTMCP_LOG_LEVEL": "ERROR"
      },
      "disabled": false,
      "autoApprove": [],
      "priority": 85
    },
    "git-helper": {
      "command": "uvx",
      "args": ["git-helper-mcp-server@latest"],
      "env": {
        "FASTMCP_LOG_LEVEL": "ERROR"
      },
      "disabled": false,
      "autoApprove": ["git_status", "git_log"],
      "priority": 80
    }
  }
}
```

**الفوائد:**

- تكامل مع Flutter/Dart documentation
- تحليل الكود الآلي
- مساعدة Git محسّنة
- تحسين تجربة المطور

**الخطوات:**

1. نسخ التكوين أعلاه
2. حفظه في `.kiro/settings/mcp.json`
3. إعادة تشغيل Kiro
4. اختبار التكامل

---

#### 2. إضافة أدلة تفصيلية

**المجلد:** `.kiro/steering/guides/`

**الحالة الحالية:** مفقود  
**الأثر:** عالي  
**الوقت المقدر:** 4 ساعات

**الملفات المطلوبة:**

##### flutter-guide.md

```markdown
# دليل Flutter الكامل

## نظرة عامة

## البنية المعمارية

## إدارة الحالة

## قاعدة البيانات

## الأمان

## الأداء

## دعم RTL

## أفضل الممارسات

## الأخطاء الشائعة

## نصائح وحيل

## المراجع
```

##### git-guide.md

```markdown
# دليل Git الكامل

## نظرة عامة

## Commit Messages

## Branching Strategy

## Pull Requests

## Code Review

## Git Hooks

## أفضل الممارسات

## الأخطاء الشائعة

## نصائح وحيل

## المراجع
```

##### security-guide.md

```markdown
# دليل الأمان الكامل

## نظرة عامة

## التخزين الآمن

## Input Validation

## Hashing

## Encryption

## Authentication

## Authorization

## أفضل الممارسات

## الأخطاء الشائعة

## نصائح وحيل

## المراجع
```

##### testing-guide.md

```markdown
# دليل الاختبارات الكامل

## نظرة عامة

## Unit Tests

## Widget Tests

## Integration Tests

## Mocking

## Coverage

## أفضل الممارسات

## الأخطاء الشائعة

## نصائح وحيل

## المراجع
```

##### deployment-guide.md

```markdown
# دليل النشر الكامل

## نظرة عامة

## Android Deployment

## iOS Deployment

## Web Deployment

## CI/CD

## Versioning

## أفضل الممارسات

## الأخطاء الشائعة

## نصائح وحيل

## المراجع
```

**الخطوات:**

1. إنشاء المجلد: `mkdir -p .kiro/steering/guides/`
2. إنشاء الملفات الخمسة
3. ملء المحتوى بالتفصيل
4. تحديث `.kiro/steering/config.json`

---

#### 3. تحديث prReview.prompt.md

**الملف:** `.kiro/prompts/prReview.prompt.md`

**الحالة الحالية:** قديم  
**الأثر:** متوسط  
**الوقت المقدر:** 1 ساعة

**التحديثات المطلوبة:**

```markdown
# PR Review Prompt v2.0

## Context Gathering (MANDATORY)

1. Read PR description
2. Read changed files
3. Read related issues
4. Read test results
5. Read CI/CD results

## Review Checklist

### Code Quality

- [ ] Follows naming conventions
- [ ] Follows SOLID principles
- [ ] Follows DRY principle
- [ ] No code smells
- [ ] No technical debt

### Security

- [ ] No secrets in code
- [ ] Input validation
- [ ] Secure storage
- [ ] No SQL injection
- [ ] No XSS vulnerabilities

### Testing

- [ ] Unit tests added
- [ ] Widget tests added
- [ ] Integration tests added
- [ ] Coverage > 70%
- [ ] All tests passing

### Documentation

- [ ] DartDoc added
- [ ] README updated
- [ ] CHANGELOG updated
- [ ] Examples added
- [ ] Comments clear

### Performance

- [ ] No memory leaks
- [ ] No performance issues
- [ ] Optimized queries
- [ ] Lazy loading
- [ ] Const constructors

## Approval Gate

- Wait for explicit approval before merging
```

**الخطوات:**

1. فتح `.kiro/prompts/prReview.prompt.md`
2. تحديث المحتوى
3. حفظ الملف
4. اختبار الـ prompt

---

### 🟡 أولوية متوسطة (Important)

#### 4. إضافة قوالب جديدة

**المجلد:** `.kiro/templates/`

**الحالة الحالية:** 7 قوالب  
**الهدف:** 25 قالب  
**الأثر:** متوسط  
**الوقت المقدر:** 3 ساعات

**القوالب المقترحة:**

##### Code Templates

```bash
.kiro/templates/code/
├── repository_template.dart
├── model_template.dart
├── widget_template.dart
├── service_template.dart
├── controller_template.dart
├── use_case_template.dart
└── integration_test_template.dart
```

##### Specs Templates

```bash
.kiro/templates/specs/
├── spec_template.md
├── design_template.md
├── tasks_template.md
└── requirements_template.md
```

##### Docs Templates

```bash
.kiro/templates/docs/
├── feature_doc_template.md
├── api_doc_template.md
├── changelog_template.md
└── readme_template.md
```

##### Workflows Templates

```bash
.kiro/templates/workflows/
├── ci_template.yml
├── cd_template.yml
├── quality_gate_template.yml
└── security_scan_template.yml
```

**الخطوات:**

1. إنشاء المجلدات الفرعية
2. إنشاء القوالب
3. إضافة README.md في كل مجلد
4. اختبار القوالب

---

#### 5. إضافة سكريبتات مفيدة

**المجلد:** `.kiro/scripts/`

**الحالة الحالية:** 3 سكريبتات  
**الهدف:** 15 سكريبت  
**الأثر:** متوسط  
**الوقت المقدر:** 4 ساعات

**السكريبتات المقترحة:**

##### Setup Scripts

```bash
.kiro/scripts/setup/
├── setup-project.sh
├── install-dependencies.sh
├── configure-environment.sh
└── setup-git-hooks.sh
```

##### Testing Scripts

```bash
.kiro/scripts/testing/
├── run-tests.sh
├── generate-coverage.sh
├── run-integration-tests.sh
└── run-e2e-tests.sh
```

##### Deployment Scripts

```bash
.kiro/scripts/deployment/
├── deploy-android.sh
├── deploy-ios.sh
├── deploy-web.sh
└── deploy-all.sh
```

##### Maintenance Scripts

```bash
.kiro/scripts/maintenance/
├── backup.sh
├── cleanup.sh
├── update-dependencies.sh
└── archive-old-files.sh
```

**الخطوات:**

1. إنشاء المجلدات الفرعية
2. إنشاء السكريبتات
3. إضافة README.md
4. جعل السكريبتات قابلة للتنفيذ: `chmod +x *.sh`
5. اختبار السكريبتات

---

#### 6. تحسين الـ hooks

**المجلد:** `.kiro/hooks/`

**الحالة الحالية:** 23 hook (بعضها معطل)  
**الأثر:** متوسط  
**الوقت المقدر:** 2 ساعة

**التحسينات المقترحة:**

1. **تفعيل الـ hooks المعطلة**

```bash
# فحص الـ hooks المعطلة
grep -r "enabled: false" .kiro/hooks/

# تفعيلها
sed -i 's/enabled: false/enabled: true/g' .kiro/hooks/**/*.json
```

2. **دمج الـ hooks المتشابهة**

```bash
# مثال: دمج hooks التحقق من الجودة
# قبل: quality-check-1.json, quality-check-2.json
# بعد: quality-check.json (شامل)
```

3. **إضافة caching**

```json
{
  "name": "expensive-hook",
  "event": "onSave",
  "action": "askAgent",
  "message": "Check code quality",
  "cache": {
    "enabled": true,
    "ttl": 300,
    "key": "file-hash"
  }
}
```

4. **إضافة error handling**

```json
{
  "name": "robust-hook",
  "event": "onSave",
  "action": "askAgent",
  "message": "Analyze code",
  "errorHandling": {
    "retry": 3,
    "fallback": "log-only",
    "timeout": 30000
  }
}
```

**الخطوات:**

1. مراجعة جميع الـ hooks
2. تفعيل المعطلة
3. دمج المتشابهة
4. إضافة caching
5. إضافة error handling
6. اختبار الـ hooks

---

### 🟢 أولوية منخفضة (Nice to Have)

#### 7. تنظيف وأرشفة

**المجلدات:** `.kiro/specs/`, `.kiro/docs/reports/`

**الأثر:** منخفض  
**الوقت المقدر:** 1 ساعة

**الخطوات:**

```bash
# أرشفة المواصفات المكتملة
mkdir -p .kiro/specs/archive/2024/
mv .kiro/specs/completed-* .kiro/specs/archive/2024/

# أرشفة التقارير القديمة
mkdir -p .kiro/docs/reports/archive/2024/
mv .kiro/docs/reports/*_2024_*.md .kiro/docs/reports/archive/2024/

# حذف الملفات المؤقتة
find .kiro/ -name "*.tmp" -delete
find .kiro/ -name "*.bak" -delete
find .kiro/ -name ".DS_Store" -delete
```

---

#### 8. إضافة فهارس

**الملفات:** `.kiro/templates/README.md`, `.kiro/scripts/README.md`, `.kiro/docs/INDEX.md`

**الأثر:** منخفض  
**الوقت المقدر:** 1 ساعة

**الخطوات:**

1. إنشاء `.kiro/templates/README.md`
2. إنشاء `.kiro/scripts/README.md`
3. تحديث `.kiro/docs/INDEX.md`
4. إضافة روابط بين الفهارس

---

#### 9. تحسين التوثيق

**الأثر:** منخفض  
**الوقت المقدر:** 2 ساعة

**التحسينات:**

1. إضافة أمثلة عملية أكثر
2. إضافة screenshots حيثما أمكن
3. إضافة video tutorials links
4. إضافة FAQ sections
5. إضافة troubleshooting guides

---

## 📊 جدول التنفيذ

### الأسبوع 1: الأساسيات

| اليوم       | المهمة                   | الوقت | الأولوية |
| :---------- | :----------------------- | :---- | :------- |
| الإثنين     | إضافة تكوين MCP          | 30د   | 🔴       |
| الثلاثاء    | flutter-guide.md         | 1س    | 🔴       |
| الأربعاء    | git-guide.md             | 1س    | 🔴       |
| الخميس      | security-guide.md        | 1س    | 🔴       |
| الجمعة      | testing-guide.md         | 1س    | 🔴       |
| السبت       | deployment-guide.md      | 1س    | 🔴       |
| الأحد       | تحديث prReview.prompt.md | 1س    | 🔴       |
| **المجموع** |                          | 6.5س  |          |

**التقييم المتوقع بعد الأسبوع 1:** 95/100

---

### الأسبوع 2: التوسع

| اليوم       | المهمة              | الوقت | الأولوية |
| :---------- | :------------------ | :---- | :------- |
| الإثنين     | قوالب Code          | 1.5س  | 🟡       |
| الثلاثاء    | قوالب Specs         | 1س    | 🟡       |
| الأربعاء    | قوالب Docs          | 1س    | 🟡       |
| الخميس      | قوالب Workflows     | 1س    | 🟡       |
| الجمعة      | سكريبتات Setup      | 1س    | 🟡       |
| السبت       | سكريبتات Testing    | 1س    | 🟡       |
| الأحد       | سكريبتات Deployment | 1س    | 🟡       |
| **المجموع** |                     | 7.5س  |          |

**التقييم المتوقع بعد الأسبوع 2:** 97/100

---

### الأسبوع 3: التحسين

| اليوم       | المهمة                | الوقت | الأولوية |
| :---------- | :-------------------- | :---- | :------- |
| الإثنين     | سكريبتات Maintenance  | 1س    | 🟡       |
| الثلاثاء    | تحسين hooks (تفعيل)   | 30د   | 🟡       |
| الأربعاء    | تحسين hooks (دمج)     | 30د   | 🟡       |
| الخميس      | تحسين hooks (caching) | 30د   | 🟡       |
| الجمعة      | تحسين hooks (error)   | 30د   | 🟡       |
| السبت       | تنظيف وأرشفة          | 1س    | 🟢       |
| الأحد       | إضافة فهارس           | 1س    | 🟢       |
| **المجموع** |                       | 5س    |          |

**التقييم المتوقع بعد الأسبوع 3:** 98/100

---

### الأسبوع 4: الصقل

| اليوم       | المهمة          | الوقت | الأولوية |
| :---------- | :-------------- | :---- | :------- |
| الإثنين     | تحسين التوثيق   | 2س    | 🟢       |
| الثلاثاء    | مراجعة شاملة    | 2س    | 🔴       |
| الأربعاء    | اختبار المكونات | 2س    | 🔴       |
| الخميس      | تحديث الوثائق   | 2س    | 🔴       |
| الجمعة      | اختبار نهائي    | 2س    | 🔴       |
| السبت       | إصلاح المشاكل   | 2س    | 🔴       |
| الأحد       | نشر التحديثات   | 1س    | 🔴       |
| **المجموع** |                 | 13س   |          |

**التقييم المتوقع بعد الأسبوع 4:** 100/100 ⭐⭐⭐⭐⭐

---

## 📈 مقاييس النجاح

### قبل التحسينات

| المقياس               | القيمة |
| :-------------------- | -----: |
| **التقييم الإجمالي**  | 92/100 |
| **عدد القوالب**       |      7 |
| **عدد السكريبتات**    |      3 |
| **عدد الأدلة**        |      0 |
| **تكامل MCP**         |      0 |
| **hooks مفعّلة**      |    75% |
| **التغطية التوثيقية** |    85% |

### بعد التحسينات

| المقياس               | القيمة | التحسين |
| :-------------------- | -----: | ------: |
| **التقييم الإجمالي**  |    100 |      +8 |
| **عدد القوالب**       |     25 |     +18 |
| **عدد السكريبتات**    |     15 |     +12 |
| **عدد الأدلة**        |      5 |      +5 |
| **تكامل MCP**         |      3 |      +3 |
| **hooks مفعّلة**      |    95% |    +20% |
| **التغطية التوثيقية** |    98% |    +13% |

---

## ✅ قائمة التحقق النهائية

### الأسبوع 1

- [ ] إضافة تكوين MCP
- [ ] إنشاء flutter-guide.md
- [ ] إنشاء git-guide.md
- [ ] إنشاء security-guide.md
- [ ] إنشاء testing-guide.md
- [ ] إنشاء deployment-guide.md
- [ ] تحديث prReview.prompt.md

### الأسبوع 2

- [ ] إضافة قوالب Code (7 قوالب)
- [ ] إضافة قوالب Specs (4 قوالب)
- [ ] إضافة قوالب Docs (4 قوالب)
- [ ] إضافة قوالب Workflows (4 قوالب)
- [ ] إضافة سكريبتات Setup (4 سكريبتات)
- [ ] إضافة سكريبتات Testing (4 سكريبتات)
- [ ] إضافة سكريبتات Deployment (4 سكريبتات)

### الأسبوع 3

- [ ] إضافة سكريبتات Maintenance (4 سكريبتات)
- [ ] تفعيل hooks المعطلة
- [ ] دمج hooks المتشابهة
- [ ] إضافة caching للـ hooks
- [ ] إضافة error handling للـ hooks
- [ ] تنظيف وأرشفة
- [ ] إضافة فهارس

### الأسبوع 4

- [ ] تحسين التوثيق
- [ ] مراجعة شاملة
- [ ] اختبار جميع المكونات
- [ ] تحديث جميع الوثائق
- [ ] اختبار نهائي
- [ ] إصلاح المشاكل
- [ ] نشر التحديثات

---

## 🎯 الخلاصة

**الوقت الإجمالي المقدر:** 32 ساعة (4 أسابيع × 8 ساعات/أسبوع)

**التحسين المتوقع:** من 92/100 إلى 100/100 (+8 نقاط)

**الأولويات:**

1. 🔴 **أولوية عالية** - 6.5 ساعة - تحسين +3 نقاط
2. 🟡 **أولوية متوسطة** - 12.5 ساعة - تحسين +4 نقاط
3. 🟢 **أولوية منخفضة** - 3 ساعة - تحسين +1 نقطة
4. **المراجعة والصقل** - 10 ساعات - ضمان الجودة

**النتيجة النهائية:** مجلد `.kiro/` بتقييم 100/100 ⭐⭐⭐⭐⭐

---

**تم إعداده بواسطة:** فريق وكلاء تطوير مشروع بصير  
**التاريخ:** 8 ديسمبر 2025  
**الإصدار:** 1.0  
**الحالة:** ✅ جاهز للتنفيذ
