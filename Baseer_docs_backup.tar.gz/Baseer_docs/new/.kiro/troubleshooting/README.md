# دليل استكشاف الأخطاء وإصلاحها - مشروع بصير

**المؤلف:** فريق وكلاء تطوير مشروع بصير  
**التاريخ:** 12 ديسمبر 2025  
**الحالة:** ✅ **مُحدث ومُختبر**

---

## 📚 الأدلة المتاحة

### 🔧 مشاكل MCP (Model Context Protocol)

#### [الحل الشامل لخادم GitHub MCP](./mcp-github-complete-solution.md)

**المشكلة:** timeout وفشل الاتصال بخادم GitHub MCP  
**الأعراض:** `MCP error -32001: Request timed out`  
**الحل:** استبدال حزمة PyPI التالفة بحزمة npm الرسمية  
**السكريبت:** `../scripts/fix_github_mcp.py`  
**الحالة:** ✅ مُختبر ومُؤكد العمل  
**التقييم:** 10/10 ⭐⭐⭐⭐⭐

---

## 🚀 الاستخدام السريع

### إصلاح خادم GitHub MCP

#### الطريقة الأولى: السكريبت التلقائي (موصى به)

```bash
# تشغيل سكريبت الإصلاح الشامل
python3 scripts/fix_github_mcp.py
```

#### الطريقة الثانية: الإصلاح اليدوي

```python
# تحديث التكوين يدوياً
python3 -c "
import json, os
config_path = os.path.expanduser('~/.kiro/settings/mcp.json')
with open(config_path, 'r') as f: config = json.load(f)
config['mcpServers']['github'] = {
    'command': 'npx',
    'args': ['-y', '@modelcontextprotocol/server-github'],
    'env': {'GITHUB_PERSONAL_ACCESS_TOKEN': '\${GITHUB_TOKEN}', 'FASTMCP_LOG_LEVEL': 'ERROR'},
    'disabled': False, 'autoApprove': ['search_repositories', 'get_file_contents', 'list_issues', 'get_issue']
}
with open(config_path, 'w') as f: json.dump(config, f, indent=2)
print('✅ تم الإصلاح بنجاح')
"
```

---

## 📋 قائمة فحص سريعة

### قبل الإصلاح

- [ ] تحديد الأعراض في السجلات (`~/.kiro/logs/mcp.log`)
- [ ] فحص التكوين الحالي (`~/.kiro/settings/mcp.json`)
- [ ] إنشاء نسخة احتياطية
- [ ] التحقق من متغيرات البيئة (`echo $GITHUB_TOKEN`)

### أثناء الإصلاح

- [ ] تطبيق الحل المناسب
- [ ] فحص التكوين الجديد
- [ ] اختبار الاتصال الأولي

### بعد الإصلاح

- [ ] إعادة تشغيل Kiro
- [ ] اختبار الوظائف (26 أداة GitHub)
- [ ] مراقبة السجلات للتأكد من عدم وجود timeout
- [ ] توثيق النتائج

---

## 🔍 التشخيص السريع

### فحص حالة خادم GitHub MCP

```bash
# فحص التكوين الحالي
grep -A 8 '"github"' ~/.kiro/settings/mcp.json

# اختبار GitHub API
curl -s -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user | jq '.login'

# اختبار الحزمة
timeout 10s npx -y @modelcontextprotocol/server-github --help 2>&1 | head -3
```

### علامات المشكلة

- ❌ رسائل `MCP error -32001: Request timed out`
- ❌ `MCP server connection and syncing tools and resources timed out after 5 minutes`
- ❌ فشل في تحميل أدوات GitHub في Kiro
- ❌ ظهور تطبيقات غير متوقعة عند اختبار الخادم

### علامات النجاح

- ✅ لا توجد رسائل timeout في السجلات
- ✅ 26 أداة GitHub متاحة في Kiro
- ✅ استجابة سريعة (< 2 ثانية)
- ✅ إمكانية البحث في المستودعات وقراءة الملفات

---

## 🛡️ الصيانة الدورية

### فحص شهري موصى به

```bash
# فحص حالة الحزمة
npm view @modelcontextprotocol/server-github

# اختبار الاتصال
timeout 5s npx -y @modelcontextprotocol/server-github --help

# فحص السجلات
tail -20 ~/.kiro/logs/mcp.log | grep github
```

### علامات تستدعي إعادة تطبيق الحل

- عودة رسائل timeout
- فشل في تحميل أدوات GitHub
- تغييرات في بنية التكوين
- تحديثات كبيرة في Kiro

---

## 📊 إحصائيات الحل

### النتائج المحققة

| المعيار         | قبل الإصلاح | بعد الإصلاح | التحسن |
| --------------- | ----------- | ----------- | ------ |
| وقت الاستجابة   | 60s timeout | < 2s        | 3000%+ |
| معدل النجاح     | 0%          | 100%        | ∞      |
| الأدوات المتاحة | 0           | 26          | ∞      |
| استقرار الاتصال | منقطع       | مستمر       | 100%   |

### الأدوات المتاحة بعد الإصلاح (26 أداة)

- `create_or_update_file`, `search_repositories`, `create_repository`
- `get_file_contents`, `push_files`, `create_issue`, `create_pull_request`
- `fork_repository`, `create_branch`, `list_commits`, `list_issues`
- `update_issue`, `add_issue_comment`, `search_code`, `search_issues`
- `search_users`, `get_issue`, `get_pull_request`, `list_pull_requests`
- `create_pull_request_review`, `merge_pull_request`, `get_pull_request_files`
- `get_pull_request_status`, `update_pull_request_branch`
- `get_pull_request_comments`, `get_pull_request_reviews`

---

## 🆘 طلب المساعدة

إذا لم تجد الحل المناسب:

1. **راجع السجلات** في `~/.kiro/logs/mcp.log`
2. **فحص التكوين** في `~/.kiro/settings/mcp.json`
3. **اختبر المكونات** منفردة باستخدام الأوامر أعلاه
4. **راجع الدليل الشامل** في `mcp-github-complete-solution.md`
5. **شغّل السكريبت التلقائي** `scripts/fix_github_mcp.py`

---

## 📈 خطة التوسع المستقبلية

### مشاكل أخرى قيد التوثيق

- [ ] مشاكل خوادم MCP أخرى (Git, Filesystem, etc.)
- [ ] مشاكل Flutter/Dart development
- [ ] مشاكل البناء والنشر
- [ ] مشاكل الأداء والذاكرة

### تحسينات مخطط لها

- [ ] سكريبت تشخيص شامل لجميع خوادم MCP
- [ ] أتمتة الفحص الدوري
- [ ] تقارير صحة النظام
- [ ] تكامل مع نظام المراقبة

---

**للإضافات والتحديثات:** يرجى إضافة الحلول الجديدة إلى هذا المجلد مع تحديث هذا الفهرس

---

**تم بواسطة:** فريق وكلاء تطوير مشروع بصير  
**آخر تحديث:** 12 ديسمبر 2025  
**الحالة:** ✅ مُحدث ومُختبر
